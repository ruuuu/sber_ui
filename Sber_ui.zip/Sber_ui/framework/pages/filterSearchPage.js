const FilterSearchPage = function() { 

  const searchInnField = ('[placeholder="Введите ИНН"]'); // поле поиска по ИНН
  // /html/body/div/div/div/div/div[2]/div/div[3]/div[3]/div[1]/div/div/
  //table/tbody/tr/td[1]/span
  const innCell = ('table>tbody>tr>td:nth-child(1)>span'); //  ячейка ИНН НП


  this.searchTaxpayerByInn = async function (page, inn){   // поиск по ИНН
    
    await page.fill(searchInnField, inn); // вбиваем Инн в поле поиска
    //await page.click(); // жмем на плашку Досье налогоплателщика

    
  };



};


export { FilterSearchPage };