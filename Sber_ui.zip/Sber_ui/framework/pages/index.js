import { SberLoginPage } from './sberLoginPage'; 
import { CreateTaxpayerPage } from './createTaxpayerPage'; 
import { DataGenerate } from './data';
import { LocatorPage } from './locatorPage'; 

const url = 'https://sber.cprr-dev.weintegrator.com/login';


const app = () => ({  //  фукнция
    sberLoginPage: ()  => new SberLoginPage(), 
    createTaxpayerPage: () => new CreateTaxpayerPage(),
    locatorPage: () => new LocatorPage(),
    data: () => new DataGenerate(),
});


export { app, url }; 