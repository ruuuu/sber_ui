const SberLoginPage = function(){ 

  const loginField = ('[data-field-name="login"]');
  const passwordField = ('[data-field-name="password"]');
  const loginButton = ('button'); // кнопка Войти
  
  
  this.login = async function (page, name, password){  // метод Логин
    await page.fill(loginField, name);  

    await page.fill(passwordField, password); 
    
    await page.click(loginButton); // кликаем кнопку Логин
  };


};

export { SberLoginPage }; 